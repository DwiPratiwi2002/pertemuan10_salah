package com.example.pertemuan10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class lihat_data extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lihat_data);
    }
}